#include <stdio.h>
#include <stdlib.h>

int tch(char c, char h){
	int m = (c - '0') * 10 + h - '0' ;
	return m;
}

int main()
{
	char date[12];
	scanf("%s", date);
	int count = 0, it = 0;
	char month[32];

	FILE *fw = fopen("date.txt", "w");
	FILE *fr = fopen("month.txt", "r");

		while(fscanf(fr, "%s", month) != EOF){
			it++;
  			if(it == tch(date[3],date[4])){
				printf("%c%c-%s, %c%c%c%c-yil\n",
					date[0],date[1],month,date[6],date[7],date[8],date[9]);
				break;
			}
		}

	fclose(fr);
	fclose(fw);

	return 0;
}
